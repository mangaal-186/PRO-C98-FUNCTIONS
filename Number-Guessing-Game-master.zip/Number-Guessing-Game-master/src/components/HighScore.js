import React from 'react';

const HighScore = (props) => {
    return (
        <div>
            {props.didWin}
        </div>)
}

export default HighScore;


